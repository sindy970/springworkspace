package com.icia.board2.dto;

import lombok.Data;

@Data
public class CommentDTO {
	private int cnumber;
	private int cbnumber;
	private String cwriter;
	private String ccontents;
}
